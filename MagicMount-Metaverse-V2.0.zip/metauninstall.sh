#!/system/bin/sh
############################################
# Magic Mount Metaverse - metauninstall.sh
# Cleanup script
# Author: GitHub@FHYUYO/酷安@枫原羽悠
############################################

EXTENDED_CONFIG_FILE="/data/adb/magic_mount/mm_extended.conf"

# Remove stealth files
rm -f /data/adb/magic_mount/.current_id 2>/dev/null

# Cleanup backup if needed
BACKUP_DIR=$(awk -F= '/^[[:space:]]*backup_dir[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "")

# Ask user if they want to keep backups
# For now, we'll keep the backup directory

exit 0
