#!/system/bin/sh
############################################
# Magic Mount Metaverse - customize.sh
# Enhanced installation script with stealth features
# Author: GitHub@FHYUYO/酷安@枫原羽悠
############################################
am start -a android.intent.action.VIEW -d https://qm.qq.com/q/iFJs3xVgj0 >/dev/null 2>&1

SKIPUNZIP=1

# Module configuration
MODULE_ID="Magic-Mount-Metaverse"
MODULE_DATA_DIR="/data/adb/magic_mount"
METAMODULE_LINK="/data/adb/metamodule"

ui_print ""
ui_print "╔═══════════════════════════════════════╗"
ui_print "║     Magic Mount Metaverse v2.0 Installer     ║"
ui_print "╚═══════════════════════════════════════╝"
ui_print ""

ui_print "[*] File integrity check..."

# Extract all files to temporary directory
if ! unzip -o "${ZIPFILE}" -d "${TMPDIR}" >/dev/null 2>&1; then
    abort "[!] Failed to extract ZIP file"
fi

# Verify checksums
(
    cd "${TMPDIR}" || abort "[!] Failed to change directory to TMPDIR"
    
    if [ ! -f "checksums" ]; then
        abort "[!] checksums file not found in package"
    fi
    
    if sha256sum -c -s "checksums" >/dev/null 2>&1; then
        ui_print "[+] File integrity verification passed"
    else
        ui_print "[!] Warning: Checksum mismatch, continuing anyway..."
    fi
)

ui_print ""
ui_print "[*] Detecting device architecture..."

# Detect architecture using ro.product.cpu.abi
ABI=$(getprop ro.product.cpu.abi)

if [ -z "$ABI" ]; then
    abort "[!] Failed to detect device architecture"
fi

ui_print "    Detected ABI: $ABI"

# Select the correct binary based on architecture
case "$ABI" in
    arm64-v8a)
        ui_print "    [✓] Selected architecture: ARM64"
        ARCH_BINARY="mm_arm64"
        ;;
    armeabi-v7a)
        ui_print "    [✓] Selected architecture: ARMv7"
        ARCH_BINARY="mm_armv7"
        ;;
    x86_64)
        ui_print "    [✓] Selected architecture: x86_64"
        ARCH_BINARY="mm_amd64"
        ;;
    *)
        abort "[!] Unsupported architecture: $ABI"
        ;;
esac

ui_print ""
ui_print "[*] Installing architecture-specific binary..."

# Verify the selected binary exists
if [ ! -f "$TMPDIR/bin/$ARCH_BINARY" ]; then
    abort "[!] Binary not found: $ARCH_BINARY"
fi

# Ensure MODPATH exists
mkdir -p "$MODPATH" || abort "[!] Failed to create module directory"

# Install the binary
if ! cp "$TMPDIR/bin/$ARCH_BINARY" "$MODPATH/mmd"; then
    abort "[!] Failed to install binary"
fi

# Set executable permissions with stealth attributes
if ! chmod 755 "$MODPATH/mmd"; then
    abort "[!] Failed to set binary permissions"
fi

ui_print "    [✓] Installed $ARCH_BINARY as magic_mount"

ui_print ""
ui_print "[*] Applying stealth attributes..."

# Create stealth helper scripts
cat > "$MODPATH/stealth.sh" << 'STEALTH_EOF'
#!/system/bin/sh
############################################
# Stealth Helper Script
# Provides anti-detection and hide functions
############################################

STEALTH_DATA_DIR="/data/adb/magic_mount"
CONFIG_FILE="$STEALTH_DATA_DIR/mm.conf"
EXTENDED_CONFIG_FILE="$STEALTH_DATA_DIR/mm_extended.conf"

# Load configuration from extended config file
load_config() {
    eval $(awk -F= '
        /^[[:space:]]*stealth_mode[[:space:]]*=/ { gsub(/[[:space:]]/, "", $0); print "STEALTH_MODE=" substr($0, index($0, "=") + 1) }
        /^[[:space:]]*randomize_id[[:space:]]*=/ { gsub(/[[:space:]]/, "", $0); print "RANDOMIZE_ID=" substr($0, index($0, "=") + 1) }
        /^[[:space:]]*hide_mount_logs[[:space:]]*=/ { gsub(/[[:space:]]/, "", $0); print "HIDE_MOUNTS=" substr($0, index($0, "=") + 1) }
        /^[[:space:]]*alternate_path[[:space:]]*=/ { gsub(/[[:space:]]/, "", $0); print "ALT_PATH=" substr($0, index($0, "=") + 1) }
        /^[[:space:]]*spoof_name[[:space:]]*=/ { gsub(/[[:space:]]/, "", $0); print "SPOOF_NAME=" substr($0, index($0, "=") + 1) }
        /^[[:space:]]*hide_from_list[[:space:]]*=/ { gsub(/[[:space:]]/, "", $0); print "HIDE_LIST=" substr($0, index($0, "=") + 1) }
    ' "$EXTENDED_CONFIG_FILE" 2>/dev/null)
}

# Randomize module ID
randomize_module_id() {
    if [ "$RANDOMIZE_ID" = "true" ]; then
        local new_id="mm_$(cat /dev/urandom | tr -dc 'a-z0-9' | head -c 8)"
        echo "$new_id" > "$STEALTH_DATA_DIR/.current_id"
        echo "$new_id"
        return 0
    fi
    
    if [ -f "$STEALTH_DATA_DIR/.current_id" ]; then
        cat "$STEALTH_DATA_DIR/.current_id"
        return 0
    fi
    
    echo "Magic-Mount-Metaverse"
}

# Get spoofed module name
get_spoof_name() {
    if [ -n "$SPOOF_NAME" ] && [ "$SPOOF_NAME" != "" ]; then
        echo "$SPOOF_NAME"
        return 0
    fi
    echo "Magic Mount"
}

# Check if mount logs should be hidden
should_hide_mounts() {
    [ "$HIDE_MOUNTS" = "true" ]
}

# Get alternate module path
get_alternate_path() {
    if [ -n "$ALT_PATH" ] && [ "$ALT_PATH" != "" ]; then
        echo "$ALT_PATH"
        return 0
    fi
    echo "/data/adb/modules"
}

# Hide from module list
hide_from_module_list() {
    [ "$HIDE_LIST" = "true" ]
}

# Clean traces in log
sanitize_log() {
    local logfile="$1"
    if [ -f "$logfile" ] && should_hide_mounts; then
        # Remove mount operation traces
        sed -i 's/mounting.*//g' "$logfile" 2>/dev/null
        sed -i 's/overlay.*//g' "$logfile" 2>/dev/null
    fi
}

# Main
case "$1" in
    get_id) randomize_module_id ;;
    get_name) get_spoof_name ;;
    hide_mounts) should_hide_mounts ;;
    alt_path) get_alternate_path ;;
    hide_list) hide_from_module_list ;;
    sanitize) sanitize_log "$2" ;;
    *) echo "Usage: $0 {get_id|get_name|hide_mounts|alt_path|hide_list|sanitize <logfile>}" ;;
esac
STEALTH_EOF

chmod 700 "$MODPATH/stealth.sh"

ui_print "    [✓] Stealth helper installed"

ui_print ""
ui_print "[*] Configuring module properties..."

# Modify module.prop with correct module ID and metamodule flag
if ! sed -i "s|^id=.*|id=$MODULE_ID|" "$TMPDIR/module.prop"; then
    abort "[!] Failed to set module ID"
fi

if ! sed -i "s|^metamodule=.*|metamodule=1|" "$TMPDIR/module.prop"; then
    abort "[!] Failed to set metamodule flag"
fi

ui_print "    [✓] Module ID: $MODULE_ID"

ui_print ""
ui_print "[*] Installing module files..."

# Define files to install
module_files="
    module.prop
"

# Scripts that need executable permissions
executable_scripts="
    metainstall.sh
    metauninstall.sh
    metamount.sh
    uninstall.sh
"

# Directories to copy recursively
module_dirs="
    webroot
"

# Copy regular module files
for f in ${module_files}; do
    if [ ! -f "$TMPDIR/$f" ]; then
        ui_print "    [!] Warning: $f not found, skipping"
        continue
    fi
    
    if ! cp "$TMPDIR/$f" "$MODPATH/$f"; then
        abort "[!] Failed to copy $f"
    fi
    
    chmod 0644 "$MODPATH/$f" || abort "[!] Failed to set permissions for $f"
    ui_print "    [✓] Installed: $f"
done

# Copy executable scripts
for f in ${executable_scripts}; do
    if [ ! -f "$TMPDIR/$f" ]; then
        ui_print "    [!] Warning: $f not found, skipping"
        continue
    fi
    
    if ! cp "$TMPDIR/$f" "$MODPATH/$f"; then
        abort "[!] Failed to copy $f"
    fi
    
    chmod 0755 "$MODPATH/$f" || abort "[!] Failed to set permissions for $f"
    ui_print "    [✓] Installed: $f (executable)"
done

# Copy directories
for d in ${module_dirs}; do
    if [ ! -d "$TMPDIR/$d" ]; then
        ui_print "    [!] Warning: $d not found, skipping"
        continue
    fi
    
    if ! cp -r "$TMPDIR/$d" "$MODPATH/"; then
        abort "[!] Failed to copy directory $d"
    fi
    
    ui_print "    [✓] Installed: $d/"
done

# Detect and set environment
if [ "x$KSU" = "xtrue" ] && [ "x$APATCH" = "xtrue" ]; then
  abort "[!] Conflicting root environments detected"
elif [ "x$KSU" = "xtrue" ]; then
  AOK="KSU"
  echo "AOK=KSU" > "$MODPATH/aok"
  ui_print "    [✓] Running on KernelSU"
elif [ "x$APATCH" = "xtrue" ]; then
  AOK="APATCH"
  echo "AOK=APATCH" > "$MODPATH/aok"
  ui_print "    [✓] Running on APatch"
else
  abort "[!] No supported root environment detected"
fi

ui_print ""
ui_print "[*] Initializing configuration..."

# Create data directory
if ! mkdir -p "$MODULE_DATA_DIR"; then
    abort "[!] Failed to create data directory"
fi

# Remove old configs to ensure clean installation
if [ -f "$MODULE_DATA_DIR/mm.conf" ]; then
    rm -f "$MODULE_DATA_DIR/mm.conf"
    ui_print "    [✓] Removed old mm.conf"
fi

if [ -f "$MODULE_DATA_DIR/mm_extended.conf" ]; then
    rm -f "$MODULE_DATA_DIR/mm_extended.conf"
    ui_print "    [✓] Removed old mm_extended.conf"
fi

# Install default configuration
if [ -f "$TMPDIR/mm.conf" ]; then
    if ! cp "$TMPDIR/mm.conf" "$MODULE_DATA_DIR/mm.conf"; then
        abort "[!] Failed to install default configuration"
    fi
    chmod 0600 "$MODULE_DATA_DIR/mm.conf"
    ui_print "    [✓] Installed default configuration"
else
    ui_print "    [!] Warning: Default config not found"
fi

# Install extended configuration
if [ -f "$TMPDIR/mm_extended.conf" ]; then
    if ! cp "$TMPDIR/mm_extended.conf" "$MODULE_DATA_DIR/mm_extended.conf"; then
        abort "[!] Failed to install extended configuration"
    fi
    chmod 0600 "$MODULE_DATA_DIR/mm_extended.conf"
    ui_print "    [✓] Installed extended configuration"
else
    ui_print "    [!] Warning: Extended config not found"
fi

# Adjust for APatch
if [ "$AOK" = "APATCH" ]; then
  sed -i '/^[[:space:]]*umount=true[[:space:]]*$/d' "$MODULE_DATA_DIR/mm.conf"
  ui_print "    [✓] Adjusted for APatch environment"
fi

ui_print ""
ui_print "[*] Managing metamodule status..."

# Check if metamodule symlink exists and points to a different module
if [ -L "$METAMODULE_LINK" ]; then
    metamodule_path=$(realpath "$METAMODULE_LINK" 2>/dev/null)
    
    if [ -n "$metamodule_path" ]; then
        metamodule_id=$(basename "$metamodule_path")
        
        if [ "$metamodule_id" != "$MODULE_ID" ]; then
            ui_print "    Switching from $metamodule_id to $MODULE_ID"
            
            # Mark old metamodule for removal
            if [ -f "$metamodule_path/module.prop" ]; then
                touch "$metamodule_path/remove" 2>/dev/null
                sed -i "s|^metamodule=.*|metamodule=0|" "$metamodule_path/module.prop" 2>/dev/null
            fi
            
            # Remove old symlink
            rm -f "$METAMODULE_LINK"
        else
            ui_print "    [✓] Already active metamodule"
        fi
    fi
elif [ -e "$METAMODULE_LINK" ]; then
    # If it exists but is not a symlink, remove it
    ui_print "    Cleaning up invalid metamodule link"
    rm -rf "$METAMODULE_LINK"
fi

# Create new metamodule symlink if needed
if [ ! -e "$METAMODULE_LINK" ]; then
    if ln -sf "/data/adb/modules/$MODULE_ID" "$METAMODULE_LINK"; then
        ui_print "    [✓] Activated as metamodule"
    else
        ui_print "    [!] Warning: Failed to create metamodule link"
    fi
fi

ui_print ""
ui_print "[*] Applying performance optimizations..."

# Create optimization script
cat > "$MODPATH/optimize.sh" << 'OPT_EOF'
#!/system/bin/sh
############################################
# Performance Optimization Script
############################################

EXTENDED_CONFIG_FILE="/data/adb/magic_mount/mm_extended.conf"
OPT_LEVEL=$(awk -F= '/^[[:space:]]*optimization_level[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "0")

case "$OPT_LEVEL" in
    2) # Ultra mode
        echo 3 > /proc/sys/vm/dirty_ratio 2>/dev/null
        echo 1 > /proc/sys/vm/dirty_background_ratio 2>/dev/null
        ;;
    1) # Fast mode
        echo 10 > /proc/sys/vm/dirty_ratio 2>/dev/null
        echo 5 > /proc/sys/vm/dirty_background_ratio 2>/dev/null
        ;;
    *) # Disabled
        ;;
esac

exit 0
OPT_EOF

chmod 700 "$MODPATH/optimize.sh"

# Read optimization level for display
OPT_LEVEL=$(awk -F= '/^[[:space:]]*optimization_level[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$MODULE_DATA_DIR/mm_extended.conf" 2>/dev/null || echo "0")

ui_print "    [✓] Optimization level: $OPT_LEVEL"

ui_print ""
ui_print "[*] Finalizing installation..."

ui_print ""
ui_print "═══════════════════════════════════════════"
ui_print "   Magic Mount Metaverse Installation Complete"
ui_print "═══════════════════════════════════════════"
ui_print "   Module ID:    $MODULE_ID"
ui_print "   Architecture: $ABI"
ui_print "   Binary:       $ARCH_BINARY"
ui_print "   Root:         $AOK"
ui_print "   Data Dir:     $MODULE_DATA_DIR"
ui_print "═══════════════════════════════════════════"
ui_print ""
ui_print "[+] Thank you for choosing Magic Mount Metaverse!"
ui_print ""

exit 0
