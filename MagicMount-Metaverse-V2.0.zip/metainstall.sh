#!/system/bin/sh
############################################
# Magic Mount Metaverse - metainstall.sh
# Enhanced installation functions
# Author: GitHub@FHYUYO/酷安@枫原羽悠
############################################

export KSU_HAS_METAMODULE="true"
export KSU_METAMODULE="meta-mm"

# Extended config file for shell scripts
EXTENDED_CONFIG_FILE="/data/adb/magic_mount/mm_extended.conf"

# Main installation flow
ui_print "- Using Magic Mount Pro metainstall"

# Anti-detection: Suppress props (read from extended config)
BYPASS_DETECTION=$(awk -F= '/^[[:space:]]*bypass_detection[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "true")

if [ "$BYPASS_DETECTION" = "true" ]; then
    # Create prop override file for hiding root
    echo "# Anti-detection properties" > "$MODPATH/system.prop"
    
    # Common root detection bypass props
    if [ -f "$MODPATH/system/build.prop" ]; then
        # Add stealth props
        echo "ro.build.type=userdebug" >> "$MODPATH/system/build.prop"
        echo "ro.adb.secure=0" >> "$MODPATH/system/build.prop" 2>/dev/null
    fi
    
    ui_print "- Anti-detection enabled"
fi

# we no-op handle_partition
# this way we can support normal hierarchy that ksu changes
handle_partition() {
	echo 0 > /dev/null ; true
}

mark_replace() {
	replace_target="$1"
	mkdir -p "$replace_target"
	setfattr -n trusted.overlay.opaque -v y "$replace_target" 2>/dev/null
}

# call install function, this is important!
install_module

mm_handle_partition() {
	partition="$1"
	
	if [ ! -d "$MODPATH/system/$partition" ]; then
		return
	fi
	
	if [ -L "/system/$partition" ] && [ -d "/$partition" ]; then
		ui_print "- Handle partition /$partition"
		ln -sf "./system/$partition" "$MODPATH/$partition"
	fi
}

mm_handle_partition system_ext
mm_handle_partition vendor
mm_handle_partition product

# Handle alternate partitions
ALT_PARTITIONS=$(awk -F= '/^[[:space:]]*partitions[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' /data/adb/magic_mount/mm.conf 2>/dev/null || echo "")

for part in $ALT_PARTITIONS; do
    mm_handle_partition "$part"
done

ui_print "- Installation complete"
