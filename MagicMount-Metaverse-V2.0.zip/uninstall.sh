#!/system/bin/sh
############################################
# Magic Mount Metaverse - uninstall.sh
# Cleanup script for module removal
# Author: GitHub@FHYUYO/酷安@枫原羽悠
############################################

MODDIR="${0%/*}"

# Enhanced cleanup
rm -rf /data/adb/magic_mount 2>/dev/null

# Remove metamodule link
rm -f /data/adb/metamodule 2>/dev/null

exit 0
