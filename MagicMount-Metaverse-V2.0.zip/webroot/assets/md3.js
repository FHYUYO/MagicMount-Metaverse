/**
 * Magic Mount Metaverse - Material Design 3 UI
 * Main Application Script
 */

// ===== Configuration =====
const CONFIG_PATH = '/data/adb/magic_mount/mm.conf';
const EXTENDED_CONFIG_PATH = '/data/adb/magic_mount/mm_extended.conf';
const AOK_PATH = '/data/adb/metamodule/aok';

// ===== State =====
const state = {
    theme: localStorage.getItem('mm-theme') || 'dark',
    lang: localStorage.getItem('mm-lang') || 'en',
    animations: localStorage.getItem('mm-animations') !== 'false',
    autoRefresh: parseInt(localStorage.getItem('mm-refresh') || '1'),
    showMetrics: localStorage.getItem('mm-metrics') !== 'false',
    config: {},
    stealth: {},
    modules: [],
    logs: { current: '', old: '' },
    currentLog: 'current'
};

// ===== Translations =====
const i18n = {
    en: {
        status: { mount: 'Mount', stealth: 'Stealth', modules: 'Modules' },
        metrics: { cpu: 'CPU', memory: 'Memory', disk: 'Disk' },
        tabs: { config: 'Config', modules: 'Modules', logs: 'Logs', stealth: 'Stealth' },
        config: {
            title: 'Configuration',
            moduleDir: 'Module Directory',
            logFile: 'Log File',
            mountSource: 'Mount Source',
            debug: 'Debug Mode',
            umount: 'Enable Unmount',
            partitions: 'Extra Partitions',
            pathLabel: 'Config Path'
        },
        modules: { title: 'Modules', loading: 'Loading modules...', empty: 'No modules found', path: 'Path' },
        logs: { title: 'Logs', current: 'Current', old: 'Old', refresh: 'Refresh', empty: 'No logs available' },
        stealth: {
            title: 'Stealth Settings',
            general: 'General',
            enable: 'Enable Stealth Mode',
            randomId: 'Randomize Module ID',
            hideLogs: 'Hide Mount Logs',
            hideFromList: 'Hide from Module List',
            advanced: 'Advanced',
            altPath: 'Alternate Module Path',
            spoofName: 'Spoof Module Name',
            performance: 'Performance',
            optLevel: 'Optimization Level',
            optOff: 'Disabled',
            optFast: 'Fast',
            optUltra: 'Ultra',
            mountDelay: 'Mount Delay (ms)',
            parallelMount: 'Parallel Mounting'
        },
        settings: { title: 'Settings', animations: 'Enable Animations', refresh: 'Auto Refresh (sec)', metrics: 'Show Metrics' },
        btn: { reload: 'Reload', save: 'Save' },
        toast: { loadSuccess: 'Configuration loaded', loadError: 'Failed to load config', saveSuccess: 'Saved successfully', saveError: 'Save failed' }
    },
    zh: {
        status: { mount: '挂载', stealth: '隐身', modules: '模块' },
        metrics: { cpu: 'CPU', memory: '内存', disk: '磁盘' },
        tabs: { config: '配置', modules: '模块', logs: '日志', stealth: '隐身' },
        config: {
            title: '配置',
            moduleDir: '模块目录',
            logFile: '日志文件',
            mountSource: '挂载源',
            debug: '调试模式',
            umount: '启用卸载',
            partitions: '额外分区',
            pathLabel: '配置路径'
        },
        modules: { title: '模块', loading: '正在加载模块...', empty: '未找到模块', path: '路径' },
        logs: { title: '日志', current: '当前', old: '旧日志', refresh: '刷新', empty: '暂无日志' },
        stealth: {
            title: '隐身设置',
            general: '常规',
            enable: '启用隐身模式',
            randomId: '随机化模块ID',
            hideLogs: '隐藏挂载日志',
            hideFromList: '隐藏模块列表',
            advanced: '高级',
            altPath: '备用模块路径',
            spoofName: '伪装模块名称',
            performance: '性能',
            optLevel: '优化级别',
            optOff: '禁用',
            optFast: '快速',
            optUltra: '极致',
            mountDelay: '挂载延迟 (毫秒)',
            parallelMount: '并行挂载'
        },
        settings: { title: '设置', animations: '启用动画', refresh: '自动刷新 (秒)', metrics: '显示监控' },
        btn: { reload: '重新加载', save: '保存' },
        toast: { loadSuccess: '配置已加载', loadError: '加载配置失败', saveSuccess: '保存成功', saveError: '保存失败' }
    },
    ja: {
        status: { mount: 'マウント', stealth: 'ステルス', modules: 'モジュール' },
        metrics: { cpu: 'CPU', memory: 'メモリ', disk: 'ディスク' },
        tabs: { config: '設定', modules: 'モジュール', logs: 'ログ', stealth: 'ステルス' },
        config: {
            title: '設定',
            moduleDir: 'モジュールディレクトリ',
            logFile: 'ログファイル',
            mountSource: 'マウントソース',
            debug: 'デバッグモード',
            umount: 'アンマウント有効',
            partitions: '拡張パーティション',
            pathLabel: '設定パス'
        },
        modules: { title: 'モジュール', loading: 'モジュール読み込み中...', empty: 'モジュールが見つかりません', path: 'パス' },
        logs: { title: 'ログ', current: '現在', old: '旧ログ', refresh: '更新', empty: 'ログがありません' },
        stealth: {
            title: 'ステルス設定',
            general: '一般',
            enable: 'ステルスモード有効',
            randomId: 'モジュールIDランダム化',
            hideLogs: 'マウントログ非表示',
            hideFromList: 'モジュールリスト非表示',
            advanced: '高度',
            altPath: '代替モジュールパス',
            spoofName: 'モジュール名偽装',
            performance: 'パフォーマンス',
            optLevel: '最適化レベル',
            optOff: '無効',
            optFast: '高速',
            optUltra: 'ウルトラ',
            mountDelay: 'マウント遅延 (ms)',
            parallelMount: '並列マウント'
        },
        settings: { title: '設定', animations: 'アニメーション有効', refresh: '自動更新 (秒)', metrics: 'モニタ表示' },
        btn: { reload: '再読み込み', save: '保存' },
        toast: { loadSuccess: '設定を読み込みました', loadError: '設定の読み込みに失敗', saveSuccess: '保存しました', saveError: '保存に失敗' }
    }
};

// ===== Utilities =====
function t(key) {
    const keys = key.split('.');
    let value = i18n[state.lang];
    for (const k of keys) {
        value = value?.[k];
    }
    return value || key;
}

function updateI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        el.textContent = t(key);
    });
    // Update select options
    const optLevel = document.getElementById('optLevel');
    if (optLevel) {
        optLevel.querySelector('option[value="0"]').textContent = t('stealth.optOff');
        optLevel.querySelector('option[value="1"]').textContent = t('stealth.optFast');
        optLevel.querySelector('option[value="2"]').textContent = t('stealth.optUltra');
    }
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

async function exec(command, args = {}) {
    return new Promise((resolve, reject) => {
        const callbackId = `cb_${Date.now()}_${Math.random().toString(36).substr(2)}`;
        window[callbackId] = (errno, stdout, stderr) => {
            delete window[callbackId];
            if (errno === 0) {
                resolve({ errno: 0, stdout, stderr });
            } else {
                reject(new Error(stderr || 'Command failed'));
            }
        };
        try {
            ksu.exec(command, JSON.stringify(args), callbackId);
        } catch (e) {
            delete window[callbackId];
            reject(e);
        }
    });
}

function parseBool(value) {
    if (typeof value === 'boolean') return value;
    const str = String(value).toLowerCase().trim();
    return ['1', 'true', 'yes', 'on', 'enabled'].includes(str);
}

// ===== Theme & Language =====
function initTheme() {
    document.documentElement.setAttribute('data-theme', state.theme);
    const icon = document.querySelector('.icon-theme');
    if (icon) {
        icon.innerHTML = state.theme === 'dark' 
            ? '<path fill="currentColor" d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-.46-.04-.92-.1-1.36-.98 1.37-2.58 2.26-4.4 2.26-2.98 0-5.4-2.42-5.4-5.4 0-1.81.89-3.42 2.26-4.4-.44-.06-.9-.1-1.36-.1z"/>'
            : '<path fill="currentColor" d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58c-.39-.39-1.03-.39-1.41 0-.39.39-.39 1.03 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37c-.39-.39-1.03-.39-1.41 0-.39.39-.39 1.03 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0 .39-.39.39-1.03 0-1.41l-1.06-1.06zm1.06-10.96c.39-.39.39-1.03 0-1.41-.39-.39-1.03-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36c.39-.39.39-1.03 0-1.41-.39-.39-1.03-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/>';
    }
}

function toggleTheme() {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('mm-theme', state.theme);
    initTheme();
}

function initLangDropdown() {
    const dropdown = document.getElementById('langMenu');
    const langBtn = document.getElementById('langBtn');
    const langCode = document.getElementById('langCode');
    
    if (!dropdown || !langBtn) return;

    langCode.textContent = state.lang.toUpperCase();
    
    dropdown.querySelectorAll('.lang-option').forEach(opt => {
        if (opt.dataset.lang === state.lang) {
            opt.classList.add('active');
        }
        opt.addEventListener('click', () => {
            state.lang = opt.dataset.lang;
            localStorage.setItem('mm-lang', state.lang);
            langCode.textContent = state.lang.toUpperCase();
            dropdown.querySelectorAll('.lang-option').forEach(o => o.classList.remove('active'));
            opt.classList.add('active');
            dropdown.classList.remove('active');
            updateI18n();
            loadConfig();
            loadStealth();
        });
    });

    langBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('active');
    });

    document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target) && !langBtn.contains(e.target)) {
            dropdown.classList.remove('active');
        }
    });
}

// ===== Config Operations =====
async function loadConfig() {
    try {
        const { stdout } = await exec(`cat "${CONFIG_PATH}" 2>/dev/null || echo ""`);
        const lines = stdout.split('\n');
        
        state.config = {
            module_dir: '/data/adb/modules',
            log_file: '/data/adb/magic_mount/mm.log',
            mount_source: 'KSU',
            debug: false,
            umount: true,
            partitions: '',
            hidden_packages: '',
            custom_props: ''
        };

        lines.forEach(line => {
            line = line.trim();
            if (!line || line.startsWith('#')) return;
            const [key, ...valueParts] = line.split('=');
            const value = valueParts.join('=').trim();
            if (!key) return;
            
            switch (key.trim()) {
                case 'module_dir': state.config.module_dir = value; break;
                case 'log_file': state.config.log_file = value; break;
                case 'mount_source': state.config.mount_source = value; break;
                case 'debug': state.config.debug = parseBool(value); break;
                case 'umount': state.config.umount = parseBool(value); break;
                case 'partitions': state.config.partitions = value; break;
                case 'hidden_packages': state.config.hidden_packages = value; break;
                case 'custom_props': state.config.custom_props = value; break;
            }
        });

        // Check if APatch
        try {
            const { stdout: aokData } = await exec(`cat "${AOK_PATH}" 2>/dev/null || echo ""`);
            if (aokData.includes('APATCH')) {
                state.config.isApatch = true;
            }
        } catch {}

        updateConfigUI();
        updateStatusUI();
        
        document.getElementById('configPath').textContent = `${t('config.pathLabel')}: ${CONFIG_PATH}`;
        
    } catch (e) {
        console.error('Load config error:', e);
        showToast(t('toast.loadError'), 'error');
    }
}

function updateConfigUI() {
    const c = state.config;
    document.getElementById('moduleDir').value = c.module_dir || '/data/adb/modules';
    document.getElementById('logFile').value = c.log_file || '/data/adb/magic_mount/mm.log';
    document.getElementById('mountSource').value = c.mount_source || 'KSU';
    document.getElementById('debugMode').checked = c.debug || false;
    document.getElementById('umountMode').checked = c.umount !== false;
    document.getElementById('partitions').value = c.partitions || '';
}

async function saveConfig() {
    try {
        const config = {
            module_dir: document.getElementById('moduleDir').value,
            log_file: document.getElementById('logFile').value,
            mount_source: document.getElementById('mountSource').value,
            debug: document.getElementById('debugMode').checked,
            umount: document.getElementById('umountMode').checked,
            partitions: document.getElementById('partitions').value,
            // Preserve these values from state (no UI for them)
            hidden_packages: state.config.hidden_packages || '',
            custom_props: state.config.custom_props || ''
        };

        const lines = [
            '# ===== Magic Mount Metaverse =====',
            '# Author: GitHub@FHYUYO/酷安@枫原羽悠',
            '# Version: v2.0',
            '',
            '# ====== Core Settings (Parsed by mmd binary) ======',
            `module_dir=${config.module_dir}`,
            `mount_source=${config.mount_source}`,
            `log_file=${config.log_file}`,
            `debug=${config.debug}`,
            '',
            '# ====== Unmount Settings ======',
            `umount=${config.umount}`,
            '',
            '# ====== Extended Partitions ======',
            `partitions=${config.partitions}`,
            '',
            '# ====== Anti-Detection Settings ======',
            `hidden_packages=${config.hidden_packages}`,
            `custom_props=${config.custom_props}`
        ];

        const content = lines.join('\n').replace(/'/g, "'\\''");
        const cmd = `mkdir -p "$(dirname '${CONFIG_PATH}')" && printf '%s\\n' '${content}' > '${CONFIG_PATH}'`;
        
        await exec(cmd);
        state.config = { ...state.config, ...config };
        showToast(t('toast.saveSuccess'), 'success');
        
    } catch (e) {
        console.error('Save config error:', e);
        showToast(t('toast.saveError'), 'error');
    }
}

// ===== Stealth Operations =====
async function loadStealth() {
    try {
        const { stdout } = await exec(`cat "${EXTENDED_CONFIG_PATH}" 2>/dev/null || echo ""`);
        const lines = stdout.split('\n');
        
        state.stealth = {
            stealth_mode: false,
            randomize_id: false,
            hide_mount_logs: false,
            hide_from_list: false,
            alternate_path: '',
            spoof_name: '',
            bypass_detection: true,
            optimization_level: '0',
            mount_delay: '0',
            parallel_mount: false,
            auto_backup: true,
            backup_dir: '/data/adb/magic_mount/backup'
        };

        lines.forEach(line => {
            line = line.trim();
            if (!line || line.startsWith('#')) return;
            const [key, ...valueParts] = line.split('=');
            const value = valueParts.join('=').trim();
            if (!key) return;
            
            switch (key.trim()) {
                case 'stealth_mode': state.stealth.stealth_mode = parseBool(value); break;
                case 'randomize_id': state.stealth.randomize_id = parseBool(value); break;
                case 'hide_mount_logs': state.stealth.hide_mount_logs = parseBool(value); break;
                case 'hide_from_list': state.stealth.hide_from_list = parseBool(value); break;
                case 'alternate_path': state.stealth.alternate_path = value; break;
                case 'spoof_name': state.stealth.spoof_name = value; break;
                case 'bypass_detection': state.stealth.bypass_detection = parseBool(value); break;
                case 'optimization_level': state.stealth.optimization_level = value; break;
                case 'mount_delay': state.stealth.mount_delay = value; break;
                case 'parallel_mount': state.stealth.parallel_mount = parseBool(value); break;
                case 'auto_backup': state.stealth.auto_backup = parseBool(value); break;
                case 'backup_dir': state.stealth.backup_dir = value; break;
            }
        });

        updateStealthUI();
        updateStatusUI();
        
    } catch (e) {
        console.error('Load stealth error:', e);
    }
}

function updateStealthUI() {
    const s = state.stealth;
    document.getElementById('stealthMode').checked = s.stealth_mode;
    document.getElementById('randomizeId').checked = s.randomize_id;
    document.getElementById('hideMountLogs').checked = s.hide_mount_logs;
    document.getElementById('hideFromList').checked = s.hide_from_list;
    document.getElementById('alternatePath').value = s.alternate_path || '';
    document.getElementById('spoofName').value = s.spoof_name || '';
    document.getElementById('optLevel').value = s.optimization_level || '0';
    document.getElementById('mountDelay').value = s.mount_delay || '0';
    document.getElementById('parallelMount').checked = s.parallel_mount;
}

async function saveStealth() {
    try {
        // Read existing extended config to preserve settings
        const { stdout } = await exec(`cat "${EXTENDED_CONFIG_PATH}" 2>/dev/null || echo ""`);
        
        const stealthSettings = {
            stealth_mode: document.getElementById('stealthMode').checked,
            randomize_id: document.getElementById('randomizeId').checked,
            hide_mount_logs: document.getElementById('hideMountLogs').checked,
            hide_from_list: document.getElementById('hideFromList').checked,
            alternate_path: document.getElementById('alternatePath').value,
            spoof_name: document.getElementById('spoofName').value,
            bypass_detection: state.stealth.bypass_detection,
            optimization_level: document.getElementById('optLevel').value,
            mount_delay: document.getElementById('mountDelay').value,
            parallel_mount: document.getElementById('parallelMount').checked,
            auto_backup: state.stealth.auto_backup,
            backup_dir: state.stealth.backup_dir
        };

        // Parse existing and merge
        const lines = stdout.split('\n');
        const newLines = [];
        let inStealthSection = false;
        
        lines.forEach(line => {
            const trimmed = line.trim();
            if (trimmed.startsWith('# ====== Stealth') || trimmed.startsWith('# ======')) {
                inStealthSection = true;
            }
            
            const key = trimmed.split('=')[0]?.trim();
            const stealthKeys = ['stealth_mode', 'randomize_id', 'hide_mount_logs', 'hide_from_list', 
                                 'alternate_path', 'spoof_name', 'bypass_detection',
                                 'optimization_level', 'mount_delay', 'parallel_mount',
                                 'auto_backup', 'backup_dir'];
            
            if (inStealthSection && stealthKeys.includes(key)) {
                // Skip, will add new values
                return;
            }
            
            newLines.push(line);
        });

        // Add stealth settings
        newLines.push('');
        newLines.push('# ====== Stealth Settings ======');
        newLines.push(`stealth_mode=${stealthSettings.stealth_mode}`);
        newLines.push(`randomize_id=${stealthSettings.randomize_id}`);
        newLines.push(`hide_mount_logs=${stealthSettings.hide_mount_logs}`);
        newLines.push(`hide_from_list=${stealthSettings.hide_from_list}`);
        newLines.push(`alternate_path=${stealthSettings.alternate_path}`);
        newLines.push(`spoof_name=${stealthSettings.spoof_name}`);
        newLines.push(`bypass_detection=${stealthSettings.bypass_detection}`);
        newLines.push(`optimization_level=${stealthSettings.optimization_level}`);
        newLines.push(`mount_delay=${stealthSettings.mount_delay}`);
        newLines.push(`parallel_mount=${stealthSettings.parallel_mount}`);
        newLines.push(`auto_backup=${stealthSettings.auto_backup}`);
        newLines.push(`backup_dir=${stealthSettings.backup_dir}`);

        const content = newLines.join('\n').replace(/'/g, "'\\''");
        const cmd = `printf '%s\\n' '${content}' > '${EXTENDED_CONFIG_PATH}'`;
        
        await exec(cmd);
        state.stealth = { ...state.stealth, ...stealthSettings };
        updateStatusUI();
        showToast(t('toast.saveSuccess'), 'success');
        
    } catch (e) {
        console.error('Save stealth error:', e);
        showToast(t('toast.saveError'), 'error');
    }
}

// ===== Module Operations =====
async function loadModules() {
    const listEl = document.getElementById('moduleList');
    const loadingEl = document.getElementById('modulesLoading');
    const emptyEl = document.getElementById('modulesEmpty');
    const pathEl = document.getElementById('modulePath');
    
    try {
        loadingEl.style.display = 'flex';
        emptyEl.style.display = 'none';
        
        // Clear existing items (keep loading/empty elements)
        Array.from(listEl.children).forEach(child => {
            if (child !== loadingEl && child !== emptyEl) {
                child.remove();
            }
        });

        const moduleDir = state.config.module_dir || '/data/adb/modules';
        pathEl.textContent = `${t('modules.path')}: ${moduleDir}`;

        const script = `
            MOD_DIR="${moduleDir}"
            [ -d "$MOD_DIR" ] || exit 0
            for m in "$MOD_DIR"/*; do
              [ -d "$m" ] || continue
              [ -d "$m/system" ] || continue
              name="$(basename "$m")"
              disabled=0; skip=0
              [ -e "$m/disable" ] || [ -e "$m/remove" ] && disabled=1
              [ -e "$m/skip_mount" ] && skip=1
              printf '%s|%s|%s\\n' "$name" "$disabled" "$skip"
            done
        `;

        const { stdout } = await exec(script);
        const modules = stdout.trim().split('\n')
            .filter(line => line.trim())
            .map(line => {
                const [name, disabled, skip] = line.split('|');
                return { name, disabled: disabled === '1', skip: skip === '1' };
            });

        state.modules = modules;
        document.getElementById('moduleCount').textContent = modules.length;

        loadingEl.style.display = 'none';
        
        if (modules.length === 0) {
            emptyEl.style.display = 'flex';
        } else {
            renderModules(modules);
        }

    } catch (e) {
        console.error('Load modules error:', e);
        loadingEl.style.display = 'none';
        emptyEl.style.display = 'flex';
        document.getElementById('moduleCount').textContent = '0';
    }
}

function renderModules(modules) {
    const listEl = document.getElementById('moduleList');
    
    modules.forEach((mod, index) => {
        const item = document.createElement('div');
        item.className = 'module-item';
        item.style.animationDelay = `${index * 0.05}s`;
        
        const statusClass = mod.skip ? 'skip' : (mod.disabled ? 'disabled' : 'active');
        const statusText = mod.skip ? 'Skipped' : (mod.disabled ? 'Disabled' : 'Active');
        
        item.innerHTML = `
            <span class="module-name">${escapeHtml(mod.name)}</span>
            <span class="module-status ${statusClass}">${statusText}</span>
        `;
        
        item.addEventListener('click', () => toggleModule(mod));
        listEl.appendChild(item);
    });
}

async function toggleModule(mod) {
    const moduleDir = state.config.module_dir || '/data/adb/modules';
    const skipFile = `${moduleDir}/${mod.name}/skip_mount`;
    
    try {
        if (mod.skip) {
            await exec(`rm -f "${skipFile}"`);
        } else {
            await exec(`touch "${skipFile}"`);
        }
        mod.skip = !mod.skip;
        loadModules();
    } catch (e) {
        console.error('Toggle module error:', e);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ===== Log Operations =====
async function loadLogs() {
    const contentEl = document.getElementById('logContent');
    const logFile = state.config.log_file || '/data/adb/magic_mount/mm.log';
    const suffix = state.currentLog === 'old' ? '.old' : '';
    
    try {
        contentEl.textContent = 'Loading...';
        const { stdout } = await exec(`cat "${logFile}${suffix}" 2>/dev/null || echo ""`);
        
        if (!stdout.trim()) {
            contentEl.textContent = t('logs.empty');
        } else {
            contentEl.textContent = stdout;
        }
        
        // Scroll to bottom
        const viewEl = document.getElementById('logView');
        viewEl.scrollTop = viewEl.scrollHeight;
        
    } catch (e) {
        contentEl.textContent = t('logs.empty');
    }
}

// ===== Status Updates =====
function updateStatusUI() {
    // Mount status
    const mountStatus = document.getElementById('mountStatus');
    if (state.config.mount_source) {
        mountStatus.textContent = state.config.mount_source;
        mountStatus.style.color = 'var(--md3-primary)';
    }

    // Stealth status
    const stealthStatus = document.getElementById('stealthStatus');
    if (state.stealth.stealth_mode) {
        stealthStatus.textContent = state.stealth.randomize_id ? 'Full' : 'Active';
        stealthStatus.style.color = 'var(--md3-tertiary)';
    } else {
        stealthStatus.textContent = 'Disabled';
        stealthStatus.style.color = 'var(--md3-outline)';
    }
}

// ===== Metrics =====
async function updateMetrics() {
    if (!state.showMetrics) return;
    
    try {
        // CPU
        const cpuScript = `cat /proc/stat | grep 'cpu ' | awk '{usage=($2+$4)*100/($2+$4+$5)} END {printf "%.0f", usage}'`;
        const { stdout: cpu } = await exec(cpuScript);
        const cpuVal = parseInt(cpu) || 0;
        document.getElementById('cpuBar').style.width = `${cpuVal}%`;
        document.getElementById('cpuValue').textContent = `${cpuVal}%`;

        // Memory
        const memScript = `cat /proc/meminfo | awk '/MemTotal/{t=$2} /MemAvailable/{a=$2} END {printf "%.0f", (t-a)*100/t}'`;
        const { stdout: mem } = await exec(memScript);
        const memVal = parseInt(mem) || 0;
        document.getElementById('memBar').style.width = `${memVal}%`;
        document.getElementById('memValue').textContent = `${memVal}%`;

        // Disk
        const diskScript = `df /data | tail -1 | awk '{print $5}' | tr -d '%'`;
        const { stdout: disk } = await exec(diskScript);
        const diskVal = parseInt(disk) || 0;
        document.getElementById('diskBar').style.width = `${diskVal}%`;
        document.getElementById('diskValue').textContent = `${diskVal}%`;
        
    } catch (e) {
        // Silently fail
    }
}

// ===== Tab Navigation =====
function initTabs() {
    const navTabs = document.querySelectorAll('.nav-tab');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    navTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;
            
            navTabs.forEach(t => t.classList.remove('active'));
            tabPanels.forEach(p => p.classList.remove('active'));
            
            tab.classList.add('active');
            document.getElementById(`${tabName}Panel`).classList.add('active');
            
            // Load data for tab
            if (tabName === 'modules') loadModules();
            if (tabName === 'logs') loadLogs();
            if (tabName === 'stealth') loadStealth();
        });
    });
}

// ===== Log Tabs =====
function initLogTabs() {
    const logTabs = document.querySelectorAll('.log-tab');
    
    logTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            state.currentLog = tab.dataset.log;
            logTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            loadLogs();
        });
    });
}

// ===== Initialize =====
async function init() {
    // Set theme
    initTheme();
    document.documentElement.setAttribute('data-animations', state.animations);
    
    // Initialize UI components
    initLangDropdown();
    initTabs();
    initLogTabs();
    
    // Theme toggle
    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    
    // Config buttons
    document.getElementById('reloadConfig')?.addEventListener('click', loadConfig);
    document.getElementById('saveConfig')?.addEventListener('click', saveConfig);
    
    // Modules button
    document.getElementById('reloadModules')?.addEventListener('click', loadModules);
    
    // Logs button
    document.getElementById('refreshLogs')?.addEventListener('click', loadLogs);
    
    // Stealth save button
    document.getElementById('saveStealth')?.addEventListener('click', saveStealth);
    
    // Load data
    updateI18n();
    await loadConfig();
    await loadStealth();
    await loadModules();  // Load modules count on init
    
    // Start metrics update
    setInterval(updateMetrics, state.autoRefresh * 1000);
    updateMetrics();
}

// Start app
document.addEventListener('DOMContentLoaded', init);
