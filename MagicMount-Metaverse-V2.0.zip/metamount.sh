#!/system/bin/sh
############################################
# Magic Mount Metaverse - metamount.sh
# Enhanced mount script with stealth features
# Author: GitHub@FHYUYO/酷安@枫原羽悠
############################################

MODDIR="${0%/*}"

# Binary path (architecture-specific binary selected during installation)
BINARY="$MODDIR/mmd"
STEALTH_SCRIPT="$MODDIR/stealth.sh"
OPTIMIZE_SCRIPT="$MODDIR/optimize.sh"

if [ ! -f "$BINARY" ]; then
    log "ERROR: Binary not found: $BINARY"
    exit 1
fi

# Load configuration
CONFIG_FILE="/data/adb/magic_mount/mm.conf"
EXTENDED_CONFIG_FILE="/data/adb/magic_mount/mm_extended.conf"

MM_LOG_FILE=$(awk -F= '
/^[[:space:]]*log_file[[:space:]]*=/ {
    val=$2
    sub(/#.*/, "", val)
    gsub(/^[ \t"]+|[ \t"]+$/, "", val)
    print val
}' "$CONFIG_FILE" 2>/dev/null || echo "/data/adb/magic_mount/mm.log")

# Backup old log
if [ -f "$MM_LOG_FILE" ]; then
    mv "$MM_LOG_FILE" "$MM_LOG_FILE".old 2>/dev/null
fi

# Check stealth settings (read from extended config)
STEALTH_MODE=$(awk -F= '/^[[:space:]]*stealth_mode[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "false")

HIDE_MOUNTS=$(awk -F= '/^[[:space:]]*hide_mount_logs[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "false")

# Check for optimization (read from extended config)
OPT_LEVEL=$(awk -F= '/^[[:space:]]*optimization_level[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "0")

MOUNT_DELAY=$(awk -F= '/^[[:space:]]*mount_delay[[:space:]]*=/ {
    gsub(/[[:space:]]/, "", $0)
    print substr($0, index($0, "=") + 1)
}' "$EXTENDED_CONFIG_FILE" 2>/dev/null || echo "0")

# Run optimizations if enabled
if [ -f "$OPTIMIZE_SCRIPT" ] && [ "$OPT_LEVEL" != "0" ]; then
    $OPTIMIZE_SCRIPT &
fi

# Apply mount delay if configured
if [ "$MOUNT_DELAY" -gt 0 ] 2>/dev/null; then
    usleep $((MOUNT_DELAY * 1000)) 2>/dev/null || sleep $((MOUNT_DELAY / 1000))
fi

# Set environment variables
export MODULE_METADATA_DIR="/data/adb/modules"

# Logging function with stealth support
log_msg() {
    local msg="$1"
    local level="${2:-INFO}"
    
    if [ "$HIDE_MOUNTS" = "true" ]; then
        # Sanitize potentially revealing messages
        echo "[$level] $msg" >> "$MM_LOG_FILE" 2>/dev/null
    else
        log "$msg"
        echo "[$level] $msg" >> "$MM_LOG_FILE" 2>/dev/null
    fi
}

log_msg "Magic Mount Pro v2.0 - Mount Process Started" "START"
log_msg "Stealth Mode: $STEALTH_MODE" "CONFIG"
log_msg "Metadata directory: $MODULE_METADATA_DIR" "INFO"

# Execute main binary
log_msg "Executing $BINARY" "EXEC"

if [ "$STEALTH_MODE" = "true" ]; then
    # Run in stealth mode - suppress output
    $BINARY >/dev/null 2>&1
    EXIT_CODE=$?
else
    $BINARY
    EXIT_CODE=$?
fi

if [ "$EXIT_CODE" = 0 ]; then
    log_msg "Mount completed successfully" "SUCCESS"
    
    # Sanitize log if hiding mounts
    if [ "$HIDE_MOUNTS" = "true" ] && [ -f "$MM_LOG_FILE" ]; then
        sed -i \
            -e 's/mounting.*/Mount operation processed/g' \
            -e 's/overlay\..*/Overlay fs configured/g' \
            -e 's/system_ext/Storage partition A/g' \
            -e 's/vendor/Storage partition B/g' \
            -e 's/product/Storage partition C/g' \
            "$MM_LOG_FILE" 2>/dev/null
    fi
    
    # Notify kernel
    /data/adb/ksud kernel notify-module-mounted 2>/dev/null || true
else
    log_msg "Mount failed with exit code $EXIT_CODE" "ERROR"
fi

log_msg "Mount Process Finished" "END"

exit 0
